
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.1'
version = '1.8.1'
full_version = '1.8.1'
git_revision = 'e715bce009c05bbeb5819f2b1d0468c6b776e3e3'
release = True

if not release:
    version = full_version
